function convertTemperature() {
    var temperatureInput = document.getElementById('temperature');
    var unitFromSelect = document.getElementById('unitFrom');
    var unitToSelect = document.getElementById('unitTo');
    var result = document.getElementById('result');
    // var imageUrl= "C:\Users\91957\Desktop\task2\sunny-flower-field-dandelions-on-260nw-140358574.webp";
    if (temperatureInput.value !== '') {
      var temperature = parseFloat(temperatureInput.value);
      var unitFrom = unitFromSelect.value;
      var unitTo = unitToSelect.value;
      function condition(temperature)
      {
      if(temperature<=37 && temperature>0)
      {
        document.body.style.backgroundImage = "URL('2.png')";
        return "   I'ts  good";
      
      }
      else  if(temperature>37)
      {
        document.body.style.backgroundImage = "URL('1.png')";
        return "  I'ts  Too Hot";
      }
      else 
      {
        document.body.style.backgroundImage = "URL('3.png')";
        return "  I'ts  Too Cool";
      }
    }
  
      if (unitFrom === unitTo) {
        result.innerHTML = "Please select different units.";
      } else {
        var convertedTemperature;
  
        if (unitFrom === 'celsius') {
          if (unitTo === 'fahrenheit') {
            convertedTemperature = (temperature * 9/5) + 32;
          } else if (unitTo === 'kelvin') {
            convertedTemperature = temperature + 273.15;
          }
        } else if (unitFrom === 'fahrenheit') {
          if (unitTo === 'celsius') {
            convertedTemperature = (temperature - 32) * 5/9;
          } else if (unitTo === 'kelvin') {
            convertedTemperature = (temperature + 459.67) * 5/9;
          }
        } else if (unitFrom === 'kelvin') {
          if (unitTo === 'celsius') {
            convertedTemperature = temperature - 273.15;
          } else if (unitTo === 'fahrenheit') {
            convertedTemperature = (temperature * 9/5) - 459.67;
          }
        }
  
        result.innerHTML = temperature + getUnitSymbol(unitFrom) + " is equal to " +
                            convertedTemperature.toFixed(2) + getUnitSymbol(unitTo)+ condition(temperature);
      }
    } else {
      result.innerHTML = "Please enter a temperature.";
    }
  }
  
  function getUnitSymbol(unit) {
    switch (unit) {
      case 'celsius':
        return "°C";
      case 'fahrenheit':
        return "°F";
      case 'kelvin':
        return "K";
      default:
        return "";
    }
  }
  